package br.unitins.topicos1.resource;

public @interface put {

}
